# -----------------------------------------------------------------------------------------
#
#                Listen for UDP broadcasts and display them in popup window
#                Created by alanesq in colaboration with ChatGPT - 17Jan25
#
#        Library used: pip install playsound
#
#        uses: notify-send linux app (sudo apt install libnotify4 libnotify-bin)
#              https://linuxconfig.org/how-to-send-desktop-notifications-using-notify-send
#
#        run in background with:  python UDPlistener.sh &
#                     stop with:  pkill python
#
#        send a test UDP message: echo "test message" | timeout 1 nc -u -b 192.168.1.255 12345
#           
# -----------------------------------------------------------------------------------------


#                                      S e t t i n g s
#                                      ---------------


home_folder = "/home/alan/misc/scripts/UDPlistener/"   # Where this file is located

dwellTime = 8;                                         # How long the messages stay on screen (seconds)

UDP_IP = "192.168.1.255"                               # UDP ip to use

UDP_PORT = 12345                                       # UDP port to use



# -----------------------------------------------------------------------------------------


from playsound import playsound
import socket
import subprocess
import time
from datetime import datetime, timedelta

# Send startup message
subprocess.run(["notify-send", "-t", str(dwellTime * 1000), "-i", home_folder + "icon.png", "UDP Listener" , "\nStarting"]) 



# -------------------------------------------------------------------------
#                                Output log
# -------------------------------------------------------------------------

# log a message to display (and log file -disabled)
def log_message(message):
    """Log messages to the console and a log file."""
    print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {message}")
    #with open("/home/alan/misc/scripts/ServerStuff/log.txt", "a") as log_file:
    #    log_file.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {message}")



# -------------------------------------------------------------------------
#                           listen for udp messages
# -------------------------------------------------------------------------

# Set up UDP socket

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((UDP_IP, UDP_PORT))

log_message(f"Listening for UDP messages on {UDP_IP}:{UDP_PORT}")


# -------------------------------------------------------------------------
#                                  Main loop
# -------------------------------------------------------------------------

while True:
    now = datetime.now()
    current_time = now.strftime("%H:%M")
    current_day = now.strftime("%a")

    # Handle UDP messages
    try:
        sock.settimeout(1)  # Timeout to prevent blocking scheduler
        data, addr = sock.recvfrom(2048)  # Buffer size 
        message = data.decode('utf-8')
        log_message(f"UDP from {addr}: {message}")

        # show popup message using notify-send
        subprocess.run(["notify-send", "-t", str(dwellTime * 1000), "-i", home_folder + "icon.png", "UDP Message Received" , "\n" + message]) 

        # if message starts with SY:
        if message.lower().startswith("sy:"):
            try:
                log_message("System message received")
                playsound( home_folder + "beep.mp3")
                #playsound( home_folder + "beeper.mp3")
            except Exception as e:
                log_message(f"Error with SY: message script: {e}")
                
    except socket.timeout:
        pass  # No message received
        

    time.sleep(1)  # Small delay to avoid high CPU usage
    
#end

