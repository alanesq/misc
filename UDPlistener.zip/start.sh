#!/bin/bash
echo Starting UDP listener in 10 seconds...
sleep 10
echo Starting...
python /home/alan/misc/scripts/UDPlistener/UDPlistener.py 


